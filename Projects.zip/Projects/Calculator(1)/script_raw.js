let string = '';

// Select all elements with the class 'button'
let buttons = document.querySelectorAll('.button');

// Convert the NodeList to an array and iterate over each button
Array.from(buttons).forEach((button) => {

    // Add a click event listener to each button
    button.addEventListener('click', (e) => {

        // Check if the clicked button's text is '='
        if (e.target.innerHTML == '=') {

            // Evaluate the expression in 'string' and update the input field
            string = eval(string);
            document.querySelector('input').value = string;
            localStorage.setItem('lastResult', string);
        }
        else if (e.target.innerHTML == 'AC') {
            console.log(e.target);
            string = '';
            document.querySelector('input').value = string;
        }

        else if (e.target.innerHTML == 'MR') {
            // Memory Recall: Show the last calculated result
            console.log(e.target);
            // Retrieve the last result from localStorage, or empty if not found
            let lastResult = localStorage.getItem('lastResult') || '';
            string = lastResult;
            document.querySelector('input').value = string;
        }
        // Store the result after every calculation
        else if (e.target.innerHTML == '=') {
            string = eval(string);
            document.querySelector('input').value = string;
            // Save the result to localStorage for memory recall
            localStorage.setItem('lastResult', string);
        } 
        
        else if (e.target.innerHTML == '+/-') {
            string = eval(string) * -1;
            document.querySelector('input').value = string;
            // Save the result to localStorage for memory recall
            localStorage.setItem('lastResult', string);
        }

        else {
            // Log the clicked button element to the console
            console.log(e.target);

            // Append the button's text to the 'string'
            string = string + e.target.innerHTML;

            // Update the input field with the current 'string'
            document.querySelector('input').value = string;
        }
    })
})
