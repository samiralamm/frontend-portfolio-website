    function calculatorFunctionality() {
        function getValues() {
            const x = parseFloat(document.getElementsByClassName('num1')[0].value);
            const y = parseFloat(document.getElementsByClassName('num2')[0].value);
            return { x, y };
        }

        function add() {
            const { x, y } = getValues();
            document.getElementsByClassName('result')[0].innerText = `Result: ${x + y}`;
        }

        function subtract() {
            const { x, y } = getValues();
            document.getElementsByClassName('result')[0].innerText = `Result: ${x - y}`;
        }

        function multiply() {
            const { x, y } = getValues();
            document.getElementsByClassName('result')[0].innerText = `Result: ${x * y}`;
        }

        function divide() {
            const { x, y } = getValues();
            if (y === 0) {
                document.getElementsByClassName('result')[0].innerText = 'Error: Division by zero';
            } else {
                document.getElementsByClassName('result')[0].innerText = `Result: ${x / y}`;
            }
        }

        // Example: attach to buttons
        document.getElementsByClassName('add')[0].onclick = add;
        document.getElementsByClassName('subtract')[0].onclick = subtract;
        document.getElementsByClassName('multiply')[0].onclick = multiply;
        document.getElementsByClassName('divide')[0].onclick = divide;
    }

    calculatorFunctionality();